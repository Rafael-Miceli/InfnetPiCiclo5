package Interafces;

import Model.Payment;

public interface PaymentType {
	
	void Pay(Payment payment);

}
